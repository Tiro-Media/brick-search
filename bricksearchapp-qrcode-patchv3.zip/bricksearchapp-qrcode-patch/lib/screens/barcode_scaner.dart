import 'package:bricksearch/view_models/barcode_scanner_view_model.dart';
import 'package:bricksearch/widgets/popup_mesage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

// import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:stacked/stacked.dart';

class BarcodeScanner extends StatefulWidget {
  const BarcodeScanner({Key? key}) : super(key: key);

  @override
  State<BarcodeScanner> createState() => _BarcodeScannerState();
}

class _BarcodeScannerState extends State<BarcodeScanner> {
  MobileScannerController cameraController = MobileScannerController();

  late BarCodeScannerViewModel barCodeScannerViewModel;

  // String _scanBarcode = 'Unknown';

  // Future<void> startBarcodeScanStream() async {
  //   FlutterBarcodeScanner.getBarcodeStreamReceiver('#ff6666', 'Close', true, ScanMode.BARCODE)!.listen((barcode) => print(barcode));
  // }

  // Platform messages are asynchronous, so we initialize in an async method.
  // Future<void> scanBarcodeNormal() async {
  //   String barcodeScanRes;
  //   // Platform messages may fail, so we use a try/catch PlatformException.
  //   try {
  //     barcodeScanRes = await FlutterBarcodeScanner.scanBarcode('#ff6666', 'Cancel', true, ScanMode.BARCODE);
  //     print(barcodeScanRes);
  //   } on PlatformException {
  //     barcodeScanRes = 'Failed to get platform version.';
  //   }
  //
  //   // If the widget was removed from the tree while the asynchronous platform
  //   // message was in flight, we want to discard the reply rather than calling
  //   // setState to update our non-existent appearance.
  //   if (!mounted) return;
  //
  //   setState(() {
  //     _scanBarcode = barcodeScanRes;
  //   });
  // }

  @override
  void initState() {
    // startBarcodeScanStream();
    super.initState();
  }

  _openAlert(String title, String message) {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) {
        return PopupMessage(
          clickOk: () {
            Navigator.pop(context);
            barCodeScannerViewModel.stopScanning = false;
          },
          title: title,
          message: message,
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final Size logicalSize = MediaQuery.of(context).size;
    final double _height = logicalSize.height;

    return ViewModelBuilder<BarCodeScannerViewModel>.reactive(
        viewModelBuilder: () => BarCodeScannerViewModel(),
        onModelReady: (viewModel) => viewModel.initViewModel(),
        builder: (context, viewModel, child) {
          barCodeScannerViewModel = viewModel;

          return Scaffold(
            body: Stack(
              children: [
                MobileScanner(
                  controller: cameraController,
                  onDetect: (barcode) async {
                    print(
                        'x x x x x x  SCanning   ${viewModel.busy}  - ${viewModel.stopScanning}  > > > > ');

                    if (!viewModel.busy && !viewModel.stopScanning) {
                      print('x x x x x x  SCanning  > > > > ');

                      final String? code = barcode.barcodes[0].rawValue;
                      if (code != null) {
                        viewModel.searchItemByBarcode(code).then((value) async {
                          if (!value) {
                            _openAlert("Barcode not recognised",
                                "We could not find a matching product for this barcode");
                          }
                        });
                      } else {
                        await _openAlert(
                            "Barcode not recognised", "Invalid Barcode Type");
                        viewModel.stopScanning = false;
                      }
                    }
                  },
                  scanWindow: Rect.fromLTRB(30, _height / 2 - 200, logicalSize.width - 30, _height / 2),
                ),

                // BarcodeCamera(
                //   types: const [BarcodeType.ean8, BarcodeType.ean13, BarcodeType.code128],
                //   resolution: Resolution.hd720,
                //   framerate: Framerate.fps30,
                //   mode: DetectionMode.pauseDetection,
                //   onScan: (code) {
                //     String barcaode = code.value;
                //     if(barcaode==""){
                //       _openAlert("Barcode not recognised", "Invalid Barcode Type");
                //     }else{
                //       viewModel.searchItemByBarcode(barcaode).then((value) {
                //         if (!value) {
                //           _openAlert("Barcode not recognised", "We could not find a matching product for this barcode");
                //         }
                //       });
                //     }
                //   },
                //   children:  [
                //     MaterialPreviewOverlay(animateDetection: false),
                //     BlurPreviewOverlay(),
                //     Positioned(
                //       bottom: 20,
                //       width: MediaQuery.of(context).size.width,
                //       child: Center(
                //         child: RawMaterialButton(
                //           elevation: 0.0,
                //           child: SvgPicture.asset(
                //             viewModel.busy ? 'assets/images/barcode_disabled.svg' : 'assets/images/barcode.svg',
                //             fit: BoxFit.scaleDown,
                //           ),
                //           onPressed: () {
                //             if (!viewModel.busy) {
                //               CameraController.instance.resumeDetector();
                //             }
                //           },
                //           constraints: const BoxConstraints.tightFor(
                //             width: 56.0,
                //             height: 56.0,
                //           ),
                //           shape: const CircleBorder(),
                //         ),
                //       ),
                //     )
                //   ],
                // ),

                ColorFiltered(
                  colorFilter: ColorFilter.mode(Colors.black.withOpacity(0.5), BlendMode.srcOut), // This one will create the magic
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      Container(
                        decoration: BoxDecoration(color: Colors.black, backgroundBlendMode: BlendMode.dstOut), // This one will handle background + difference out
                      ),
                      Positioned(
                        top: _height / 2 - 200,
                        width: logicalSize.width,
                        left: 0.0,
                        child: Align(
                          alignment: Alignment.center,
                          child: Container(
                              height: 200,
                              width: 300,
                              color: Colors.red,
                            ),
                          )
                      ),
                    ],
                  ),
                ),

                Positioned(
                  top: 40.0,
                  left: 10.0,
                  child: IconButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      color: Colors.white,
                      icon: const Icon(
                        Icons.close,
                        size: 32.0,
                      )),
                ),
                Positioned(
                  top: _height / 2 + 50,
                  child: SizedBox(
                      width: logicalSize.width,
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Opacity(
                                opacity: 1.0,
                                child: Column(
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(bottom: 25.0),
                                      child: IconButton(
                                        icon: SvgPicture.asset(
                                          'assets/images/barcode_button.svg',
                                          fit: BoxFit.scaleDown,
                                        ),
                                        constraints: const BoxConstraints.tightFor(
                                          width: 80.0,
                                          height: 80.0,
                                        ),
                                        iconSize: 80.0,
                                        onPressed: () { 
                                        }
                                      )
                                    ),
                                    const FittedBox(
                                      fit: BoxFit.fill,
                                      alignment: Alignment.center,
                                      child: Text("Scan LEGO set barcode", style: TextStyle(color: Colors.white, fontSize: 12 ), textAlign: TextAlign.center)
                                    )
                                  ],
                                )
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 20.0, right: 20.0),
                              child: SizedBox(
                                  width: 2.0,
                                  height: 120.0,
                                  child: DecoratedBox(
                                    decoration: BoxDecoration(
                                      shape: BoxShape.rectangle,
                                      color: Colors.white.withOpacity(0.6)
                                    ), 
                                )
                              )
                            ),
                            Opacity(
                                opacity: 1.0,
                                child: Column(
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(bottom: 25.0, top: 15.0),
                                      child: IconButton(
                                              icon: SvgPicture.asset(
                                                'assets/images/qr_button.svg',
                                                fit: BoxFit.scaleDown,
                                              ),
                                              constraints: const BoxConstraints.tightFor(
                                                width: 80.0,
                                                height: 80.0,
                                              ),
                                              iconSize: 80.0,
                                              onPressed: () { 
                                              }
                                            )
                                    ),
                                    const FittedBox(
                                      fit: BoxFit.fill,
                                      child: Text("Scan Minifigures blind\nbox (Series 25 onwards)", style: TextStyle(color: Colors.white, fontSize: 12), textAlign: TextAlign.center)
                                    )
                                  ],
                                )
                            )
                          ],
                        ),
                      ),
                ),
                Visibility(
                  visible: viewModel.busy,
                  child: const Center(child: CircularProgressIndicator()),
                ),
                // Positioned(
                //   bottom: 20,
                //   width: MediaQuery.of(context).size.width,
                //   child: Center(
                //     child: RawMaterialButton(
                //       elevation: 0.0,
                //       child: SvgPicture.asset(
                //         viewModel.busy ? 'assets/images/barcode_disabled.svg' : 'assets/images/barcode.svg',
                //         fit: BoxFit.scaleDown,
                //       ),
                //       onPressed: () {
                //         if (!viewModel.busy) {
                //           // cameraController.start().then((value) {
                //           //
                //           // });
                //         }
                //       },
                //       constraints: const BoxConstraints.tightFor(
                //         width: 56.0,
                //         height: 56.0,
                //       ),
                //       shape: const CircleBorder(),
                //     ),
                //   ),
                // )

                // CustomPaint(
                //   painter: new Sky(_width, _height),
                //   child: new Text('$_width'),
                // )
              ],
            ),
          );
        });
  }
}

class Sky extends CustomPainter {
  final double _width;
  final double _height;

  Sky(this._width, this._height);

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(
      Rect.fromLTRB(30, _height / 2 - 200, _width - 30, _height / 2),
      Paint()..color = Color(0xFF0099FF),
    );
  }

  @override
  bool shouldRepaint(Sky oldDelegate) {
    return false;
  }
}
